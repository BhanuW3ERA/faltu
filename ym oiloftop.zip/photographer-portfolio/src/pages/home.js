import React from 'react';
import { Link } from 'react-router-dom';
import Headertwo from '../components/headertwo';


const Home = () => {
  return (
    
    <>
        
        <Headertwo/>
 
        <section>
              <div className='container-fluid '> 

                    <div className='row align-items-center'>
                        <div className='col-12 col-md-6 '>
                           <div className='home_para px-4 ' data-aos="fade-up" data-aos-duration="2500">
                                <h3>HI THERE!</h3>
                                <h1>I'M <span className='name'>BENJAMIN</span></h1>

                                <div className='designation'>
                                    <p>GRAPHIC DESIGNER AND PHOTOGRAPHER</p>
                                </div>

                                <p><b>Welcome to my portfolio!</b> I specialize in crafting immersive web experiences that seamlessly blend functionality with aesthetics. With expertise in frontend development, I create user-centric interfaces that captivate and engage. From responsive layouts to intuitive navigation, I believe in the power of code to transform ideas into reality. Explore my portfolio to witness the fusion of creativity and technical expertise. Let's collaborate and build something extraordinary together.</p>

                                <Link to='/about' >KNOW MORE ABOUT ME</Link>

                           </div>
                        </div>

                        <div className='col-12 col-md-6'>
                            <div className='main_img' data-aos="fade-down" data-aos-duration="2500">
                                
                            </div>
                            
                        </div>   

                       

                    </div>

              </div>      
        </section>
        
    </>
    

  )
}

export default Home;